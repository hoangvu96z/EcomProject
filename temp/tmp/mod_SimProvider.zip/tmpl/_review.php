<?php defined('_JEXEC') or die('Restricted access');
?>
<li><a href="<?php echo $link ?>"><?php echo $review->provider_name; ?></a></li><br />